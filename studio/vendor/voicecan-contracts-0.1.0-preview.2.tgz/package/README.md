# @voicecan/contracts

Public TypeScript contracts and constants for the VoiceCan Device Platform. This package contains no server implementation, Device Core source, storage credentials, ASR, Transcript, or LLM contracts.

```bash
npm config set "@voicecan:registry" "https://git.voice-can.com/api/packages/voicecan/npm/"
npm install @voicecan/contracts
```
